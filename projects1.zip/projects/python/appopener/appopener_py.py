import webbrowser
import tkinter

from tkinter import * 
from tkinter.ttk import * 

root = Tk()
root.title('choose your app')

root.geometry('500x200')

style = Style()

style.configure('W.TButton', font =
               ('calibri', 10, 'bold', 'underline'),
                foreground = 'red')


btn = Button(root, text = 'youtube'
             style = 'W.TButton',
                          command = lambda:webbrowser.open('https://www.youtube.com', new=2))
btn.grid(row = 0, column = 0, padx = 200) 

btn1 = Button(root, text = 'hypixel',
                style = 'W.TButton',
                command = lambda:webbrowser.open('https://www.hypixel.net', new=2))
btn1.grid(row = 1, column = 0, padx = 100)

btn2 = Button(root, text = 'reddit',
                style = 'W.TButton',
                command = lambda:webbrowser.open('https://www.reddit.com', new=2))
btn2.grid(row = 2, column = 0, padx = 100) 
 
 #btn3 = Button(root, text = 'explorer', bd = '5',
                          #command = open("c:/windows/explorer.exe")    
#btn3.pack(side = 'top') 

btn3 = Button(root, text = 'Quit !',
                style = 'W.TButton',
                command = root.destroy)
btn3.grid(row = 3, column = 0, padx = 100)

root.mainloop()