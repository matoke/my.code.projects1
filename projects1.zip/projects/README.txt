thanks for downloading matteo's code packet!

this packet will be updated, so stay alert for new files.
all of the code sources can be found in "source.txt",
python and visual studio (vs) can be downloaded in "downloads.txt",
these will be found in their coresponding folder with their project.

 ALL OF THESE PROJECTS ARE MADE BY ME, AND I DID MY BEST ON IT.

all of the code can be used if you want.